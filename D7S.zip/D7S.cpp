#include "Arduino.h"
#include "D7S.h"

D7S::D7S(int pinSeleccion){
  _pinSeleccion=pinSeleccion;
  pinMode(_pinSeleccion, OUTPUT);
  for(int i=0;i<=7;i++){
    pinMode(6+i, OUTPUT); 
  }
}

void D7S::display(byte b){
  digitalWrite(_pinSeleccion, LOW);
  for(int i=0;i<=7;i++){
    if(((1<<i)&b)==(1<<i)){
      digitalWrite(6+i, HIGH);  
    }else{
      digitalWrite(6+i, LOW);
    }
  }
  digitalWrite(_pinSeleccion, HIGH);
}