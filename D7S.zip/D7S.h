#ifndef D7S_h
#define D7S_h

#include "Arduino.h"

class D7S{
	public:
		D7S(int pinSeleccion);
		void display(byte b);
	private:
		int _pinSeleccion;
};

#endif