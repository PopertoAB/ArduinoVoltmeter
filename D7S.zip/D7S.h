#ifndef D7S_h
#define D7S_h

#include "Arduino.h"

class D7S{
	public:
		D7S(int pinSeleccion, int espera);
		void display(byte b);
	private:
		int _pinSeleccion;
		int _espera;
};

#endif